# Human Miner — Fabric 1.20.1

Клиентский мод: автоматически добывает руду в выбранной области.
Требуется: Minecraft 1.20.1, Fabric Loader ≥ 0.14.21, Fabric API, Java 17.

## Клавиши (меняются в настройках управления)
- K — задать угол области (нажать 2 раза на двух блоках)
- J — старт/стоп
- L — только руды / все блоки
- H — игнорировать блок под прицелом

## Как получить готовый .jar

### Вариант 1 — командная строка (нужен JDK 17)
    Windows:  gradlew.bat build
    Linux/Mac: ./gradlew build
Файл: `build/libs/humanminer-1.0.0.jar` (не `-sources`). Положить в `.minecraft/mods` вместе с Fabric API.

### Вариант 2 — GitHub (без установки чего-либо)
Залить проект в репозиторий на GitHub → вкладка Actions → build → скачать артефакт `humanminer`.

### Вариант 3 — IntelliJ IDEA
Open → папка проекта → дождаться Gradle sync (JDK 17) → Gradle > Tasks > build > build.
