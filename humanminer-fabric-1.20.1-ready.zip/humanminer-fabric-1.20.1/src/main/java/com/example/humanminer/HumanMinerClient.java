package com.example.humanminer;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public class HumanMinerClient implements ClientModInitializer {
    private static final String CATEGORY = "key.categories.humanminer";

    @Override
    public void onInitializeClient() {
        KeyMapping toggle = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.humanminer.toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J, CATEGORY));
        KeyMapping corner = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.humanminer.corner", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, CATEGORY));
        KeyMapping mode = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.humanminer.mode", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_L, CATEGORY));
        KeyMapping ignore = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.humanminer.ignore", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, CATEGORY));

        AutoMine miner = new AutoMine();
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (corner.consumeClick()) miner.setCorner(client);
            while (mode.consumeClick()) miner.toggleMode(client);
            while (ignore.consumeClick()) miner.ignoreLookedBlock(client);
            while (toggle.consumeClick()) miner.toggle(client);
            miner.tick(client);
        });
    }
}
