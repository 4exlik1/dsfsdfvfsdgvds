package com.example.humanminer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Автошахта: в заданной области ищет ближайшую руду, подходит, прокапывает путь
 * и добывает её. Когда руды нет - ждёт обновления шахты и периодически сканирует снова.
 */
public class AutoMine {
    private static final double REACH = 4.3;
    private static final int MAX_VOLUME = 150_000;

    private final Random rng = new Random();

    private boolean active;
    private boolean oreOnly = true;

    // область
    private BlockPos p1;
    private boolean nextIsP2;
    private int minX, minY, minZ, maxX, maxY, maxZ;
    private boolean regionReady;

    // состояние
    private BlockPos target;
    private BlockPos lastBreakPos;
    private final Map<BlockPos, Integer> blacklist = new HashMap<>();
    /** Постоянный игнор-лист: декоративные/защищённые блоки. Живёт, пока открыта игра. */
    private final Set<BlockPos> ignored = new HashSet<>();
    private int tickCount, pauseTicks, reactionTicks, scanCooldown, mineTicks, walkTicks, offsetTimer;
    private float lookYawOffset, lookPitchOffset;
    private boolean idleNotified;

    // ---------------------------------------------------------------- управление

    public void setCorner(Minecraft mc) {
        if (mc.player == null) return;
        if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
            msg(mc, "Наведите прицел на блок");
            return;
        }
        BlockPos pos = hit.getBlockPos();
        if (!nextIsP2) {
            p1 = pos;
            regionReady = false;
            msg(mc, "Угол 1: " + pos.getX() + " " + pos.getY() + " " + pos.getZ() + " (теперь второй угол)");
        } else {
            int sx = Math.abs(p1.getX() - pos.getX()) + 1;
            int sy = Math.abs(p1.getY() - pos.getY()) + 1;
            int sz = Math.abs(p1.getZ() - pos.getZ()) + 1;
            if ((long) sx * sy * sz > MAX_VOLUME) {
                msg(mc, "Область слишком большая (макс. " + MAX_VOLUME + " блоков)");
                return;
            }
            minX = Math.min(p1.getX(), pos.getX()); maxX = Math.max(p1.getX(), pos.getX());
            minY = Math.min(p1.getY(), pos.getY()); maxY = Math.max(p1.getY(), pos.getY());
            minZ = Math.min(p1.getZ(), pos.getZ()); maxZ = Math.max(p1.getZ(), pos.getZ());
            regionReady = true;
            msg(mc, "Область задана: " + sx + "x" + sy + "x" + sz + ". J - старт");
        }
        nextIsP2 = !nextIsP2;
    }

    /** Клавиша H: добавить блок под прицелом в игнор-лист (или убрать, если он уже там). */
    public void ignoreLookedBlock(Minecraft mc) {
        if (mc.player == null) return;
        if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
            msg(mc, "Наведите прицел на блок");
            return;
        }
        BlockPos pos = hit.getBlockPos().immutable();
        if (ignored.remove(pos)) {
            msg(mc, "Блок снова учитывается (" + ignored.size() + " в игноре)");
        } else {
            ignored.add(pos);
            msg(mc, "Блок в игноре (" + ignored.size() + " всего)");
        }
        if (target != null && target.equals(pos)) {
            target = null;
            if (mc.gameMode != null) mc.gameMode.stopDestroyBlock();
        }
    }

    public void toggleMode(Minecraft mc) {
        oreOnly = !oreOnly;
        target = null;
        msg(mc, oreOnly ? "Режим: только руды" : "Режим: все блоки");
    }

    public void toggle(Minecraft mc) {
        if (mc.player == null) return;
        if (active) { stop(mc, "Остановлено"); return; }
        if (!regionReady) { msg(mc, "Сначала задайте область (K на двух углах)"); return; }
        active = true;
        target = null; lastBreakPos = null;
        pauseTicks = 0; scanCooldown = 0; idleNotified = false;
        reactionTicks = 8 + rng.nextInt(12);
        msg(mc, "Запущено");
    }

    private void stop(Minecraft mc, String reason) {
        active = false;
        target = null;
        releaseKeys(mc);
        if (mc.gameMode != null) mc.gameMode.stopDestroyBlock();
        msg(mc, reason);
    }

    private void msg(Minecraft mc, String text) {
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("[HumanMiner] " + text), true);
    }

    private void releaseKeys(Minecraft mc) {
        mc.options.keyUp.setDown(false);
        mc.options.keyJump.setDown(false);
    }

    // ---------------------------------------------------------------- основной цикл

    public void tick(Minecraft mc) {
        if (!active) return;
        if (mc.player == null || mc.level == null || mc.gameMode == null) { active = false; return; }

        tickCount++;
        LocalPlayer p = mc.player;

        if (mc.screen != null) { releaseKeys(mc); return; }
        if (p.getHealth() < 6) { stop(mc, "Мало здоровья"); return; }
        if (p.getInventory().getFreeSlot() == -1) { stop(mc, "Инвентарь полон"); return; }
        if (!inRegion(p.blockPosition(), 3)) { stop(mc, "Вы вышли за пределы области"); return; }
        if (dangerNearby(mc, p)) { stop(mc, "Рядом лава/жидкость, остановка"); return; }

        // паузы, как будто человек отвлёкся
        if (pauseTicks > 0) {
            pauseTicks--;
            releaseKeys(mc);
            mc.gameMode.stopDestroyBlock();
            nudge(p, (rng.nextFloat() - 0.5f) * 1.2f, (rng.nextFloat() - 0.5f) * 0.8f);
            return;
        }
        if (reactionTicks > 0) { reactionTicks--; return; }
        if (rng.nextInt(400) == 0) { pauseTicks = 15 + rng.nextInt(50); return; }

        // цель устарела?
        if (target != null && (!isTargetValid(mc, target) || isBlacklisted(target))) {
            target = null;
            mc.gameMode.stopDestroyBlock();
        }

        // ищем новую цель
        if (target == null) {
            releaseKeys(mc);
            if (--scanCooldown > 0) {
                nudge(p, (rng.nextFloat() - 0.5f) * 0.6f, (rng.nextFloat() - 0.5f) * 0.4f);
                return;
            }
            target = findTarget(mc, p);
            mineTicks = 0; walkTicks = 0;
            if (target == null) {
                scanCooldown = 40 + rng.nextInt(40); // ждём обновления шахты
                if (!idleNotified) { msg(mc, "Руды нет, жду обновления..."); idleNotified = true; }
            } else {
                idleNotified = false;
                reactionTicks = 3 + rng.nextInt(8);
            }
            return;
        }

        Vec3 eye = p.getEyePosition();
        Vec3 center = Vec3.atCenterOf(target);
        Vec3 toTarget = center.subtract(eye);
        double dist = toTarget.length();
        Vec3 end = dist > REACH ? eye.add(toTarget.normalize().scale(REACH)) : center;

        BlockHitResult hit = mc.level.clip(new ClipContext(
                eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, p));

        if (hit.getType() == HitResult.Type.MISS) {
            // путь свободен, но цель далеко - идём
            mc.gameMode.stopDestroyBlock();
            aimAt(p, mc, center, 7f);
            mc.options.keyUp.setDown(true);
            mc.options.keyJump.setDown(p.horizontalCollision && p.onGround());
            if (++walkTicks > 240) { blacklist(target); target = null; }
            return;
        }

        // на пути (или в конце пути) есть блок - ломаем его
        releaseKeys(mc);
        walkTicks = 0;
        BlockPos hp = hit.getBlockPos();
        if (!inRegion(hp, 0) || !isBreakable(mc, hp)) {
            blacklist(target);
            target = null;
            return;
        }

        if (lastBreakPos == null || !lastBreakPos.equals(hp)) {
            lastBreakPos = hp.immutable();
            mineTicks = 0;
            reactionTicks = 1 + rng.nextInt(4);
        }

        selectBestTool(p, mc.level.getBlockState(hp));
        double err = aimAt(p, mc, Vec3.atCenterOf(hp), 9f);
        if (err < 8.0) {
            if (mc.gameMode.continueDestroyBlock(hp, hit.getDirection())) {
                if (tickCount % 4 == 0) p.swing(InteractionHand.MAIN_HAND);
            }
            // Если блок не ломается заметно дольше, чем должен (сервер отменяет
            // разрушение - декоративная/защищённая руда), навсегда добавляем его в игнор.
            BlockState bs = mc.level.getBlockState(hp);
            float perTick = bs.getDestroyProgress(p, mc.level, hp);
            int expected = perTick <= 0f ? 200 : (int) Math.ceil(1.0f / perTick);
            if (++mineTicks > expected * 2 + 30) {
                ignored.add(hp.immutable());
                blacklist(target);
                target = null;
                mc.gameMode.stopDestroyBlock();
                msg(mc, "Блок не ломается, пропускаю (" + ignored.size() + " в игноре)");
            }
        }
    }

    // ---------------------------------------------------------------- поиск и проверки

    private BlockPos findTarget(Minecraft mc, LocalPlayer p) {
        Vec3 eye = p.getEyePosition();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    m.set(x, y, z);
                    BlockState s = mc.level.getBlockState(m);
                    if (s.isAir() || !isWanted(s)) continue;
                    double d = eye.distanceToSqr(x + 0.5, y + 0.5, z + 0.5);
                    if (d >= bestD) continue;
                    if (isBlacklisted(m)) continue;
                    if (!isBreakable(mc, m)) continue;
                    bestD = d;
                    best = m.immutable();
                }
            }
        }
        return best;
    }

    /** Руда = блок, чей id заканчивается на "_ore" (+ древние обломки). Работает и для модовых руд. */
    private boolean isOre(BlockState s) {
        String path = BuiltInRegistries.BLOCK.getKey(s.getBlock()).getPath();
        return path.endsWith("_ore") || path.equals("ancient_debris");
    }

    private boolean isWanted(BlockState s) {
        return !oreOnly || isOre(s);
    }

    private boolean isTargetValid(Minecraft mc, BlockPos pos) {
        if (ignored.contains(pos)) return false;
        BlockState s = mc.level.getBlockState(pos);
        return !s.isAir() && isWanted(s) && inRegion(pos, 0);
    }

    private boolean isBreakable(Minecraft mc, BlockPos pos) {
        if (ignored.contains(pos)) return false;
        BlockState s = mc.level.getBlockState(pos);
        return !s.isAir() && s.getFluidState().isEmpty() && s.getDestroySpeed(mc.level, pos) >= 0;
    }

    private boolean inRegion(BlockPos pos, int margin) {
        return pos.getX() >= minX - margin && pos.getX() <= maxX + margin
            && pos.getY() >= minY - margin && pos.getY() <= maxY + margin
            && pos.getZ() >= minZ - margin && pos.getZ() <= maxZ + margin;
    }

    private boolean dangerNearby(Minecraft mc, LocalPlayer p) {
        BlockPos f = p.blockPosition();
        BlockPos[] check = { f, f.below(), f.above(), f.north(), f.south(), f.east(), f.west() };
        for (BlockPos c : check) {
            if (!mc.level.getBlockState(c).getFluidState().isEmpty()) return true;
        }
        return false;
    }

    private void blacklist(BlockPos pos) {
        blacklist.put(pos.immutable(), tickCount + 1200);
    }

    private boolean isBlacklisted(BlockPos pos) {
        Integer until = blacklist.get(pos);
        if (until == null) return false;
        if (until < tickCount) { blacklist.remove(pos); return false; }
        return true;
    }

    private void selectBestTool(LocalPlayer p, BlockState state) {
        int best = p.getInventory().selected;
        float bestSpeed = p.getInventory().getItem(best).getDestroySpeed(state);
        for (int i = 0; i < 9; i++) {
            ItemStack st = p.getInventory().getItem(i);
            float sp = st.getDestroySpeed(state);
            if (sp > bestSpeed + 0.01f) { bestSpeed = sp; best = i; }
        }
        p.getInventory().selected = best;
    }

    // ---------------------------------------------------------------- «человеческая» камера

    /** Плавно поворачивает камеру к точке, возвращает остаточную ошибку в градусах. */
    private double aimAt(LocalPlayer p, Minecraft mc, Vec3 point, float maxSpeed) {
        if (--offsetTimer <= 0) { // медленный дрейф прицела
            offsetTimer = 15 + rng.nextInt(30);
            lookYawOffset = (rng.nextFloat() - 0.5f) * 3f;
            lookPitchOffset = (rng.nextFloat() - 0.5f) * 2f;
        }
        Vec3 eye = p.getEyePosition();
        double dx = point.x - eye.x, dy = point.y - eye.y, dz = point.z - eye.z;
        float wantYaw = (float) (Mth.atan2(dz, dx) * 180.0 / Math.PI) - 90f + lookYawOffset;
        float wantPitch = (float) -(Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI) + lookPitchOffset;

        float dYaw = Mth.wrapDegrees(wantYaw - p.getYRot());
        float dPitch = wantPitch - p.getXRot();

        float speed = maxSpeed * (0.7f + rng.nextFloat() * 0.5f);
        float stepYaw = Mth.clamp(dYaw * 0.22f, -speed, speed);
        float stepPitch = Mth.clamp(dPitch * 0.22f, -speed * 0.6f, speed * 0.6f);

        nudge(p, snapToMouse(mc, stepYaw), snapToMouse(mc, stepPitch));
        return Math.sqrt(dYaw * dYaw + dPitch * dPitch);
    }

    private void nudge(LocalPlayer p, float dYaw, float dPitch) {
        p.setYRot(p.getYRot() + dYaw);
        p.setXRot(Mth.clamp(p.getXRot() + dPitch, -90f, 90f));
    }

    /** Округление до шага чувствительности мыши, как у настоящей мышки. */
    private float snapToMouse(Minecraft mc, float delta) {
        double s = mc.options.sensitivity().get() * 0.6 + 0.2;
        double step = s * s * s * 8.0 * 0.15;
        return (float) (Math.round(delta / step) * step);
    }
}
